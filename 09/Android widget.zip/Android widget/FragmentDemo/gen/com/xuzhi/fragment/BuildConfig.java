/** Automatically generated file. DO NOT MODIFY */
package com.xuzhi.fragment;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}