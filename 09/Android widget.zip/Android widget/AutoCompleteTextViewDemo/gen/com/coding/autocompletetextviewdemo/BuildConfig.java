/** Automatically generated file. DO NOT MODIFY */
package com.coding.autocompletetextviewdemo;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}